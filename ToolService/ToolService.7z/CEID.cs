﻿using SECSInterface;

namespace ToolService
{
    public class CEID
    {
        public int Id { get; set; }
        public DataType Type { get; set; } = DataType.UI4;       
    }
}