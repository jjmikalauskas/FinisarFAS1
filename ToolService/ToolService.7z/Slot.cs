﻿namespace ToolService
{
    public class Slot
    {
        public int Id { get; set; }
    }
}