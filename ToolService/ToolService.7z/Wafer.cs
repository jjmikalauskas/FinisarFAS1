﻿
namespace ToolService
{
    public class Wafer
    {
        public long Id { get; set; }

    }   

}