﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Camstar
    {
        public string Availability { get; set; }
        public string ResourceName { get; set; }
        public string ResourceSubStateName { get; set; }
    }
}
